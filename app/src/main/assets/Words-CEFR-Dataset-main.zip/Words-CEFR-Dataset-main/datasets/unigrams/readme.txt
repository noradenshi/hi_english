To utilize the code and parse frequency data, follow these steps to download the required dataset files:

1. Visit the 1-grams dataset files webpage: https://storage.googleapis.com/books/ngrams/books/datasetsv3.html

2. Download the dataset files. Please note that the first six files contain invalid words as they include digits and other non-alphabetical characters.

3. Save the downloaded files in the current folder as .gz archives. There's no need to unpack them.
